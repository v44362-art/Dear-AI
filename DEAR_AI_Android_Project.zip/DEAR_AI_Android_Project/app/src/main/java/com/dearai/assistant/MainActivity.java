package com.dearai.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 41;
    private static final int REQ_SPEECH = 42;
    private EditText command;
    private TextView reply;
    private TextToSpeech tts;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        tts = new TextToSpeech(this, status -> { if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi", "IN")); });
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28, 48, 28, 28); root.setBackgroundColor(0xFF171126);
        TextView title = new TextView(this); title.setText("DEAR AI"); title.setTextColor(0xFFFFFFFF); title.setTextSize(32); title.setGravity(Gravity.CENTER); title.setPadding(0, 12, 0, 24); root.addView(title);
        TextView sub = new TextView(this); sub.setText("Aapka personal assistant"); sub.setTextColor(0xFFD8CBED); sub.setGravity(Gravity.CENTER); root.addView(sub);
        command = new EditText(this); command.setTextColor(0xFFFFFFFF); command.setHintTextColor(0xFFBDB3CC); command.setHint("Apni command likhein ya boliye"); command.setMinLines(2); root.addView(command, new LinearLayout.LayoutParams(-1, -2));
        addButton(root, "🎙 BOLKAR BATAYEIN", v -> startVoice());
        addButton(root, "COMMAND CHALAYEIN", v -> runCommand(command.getText().toString()));
        addButton(root, "🕒 Samay", v -> say("Abhi " + java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT, new Locale("en", "IN")).format(new java.util.Date()) + " baj rahe hain."));
        addButton(root, "📅 Aaj ki tareekh", v -> say("Aaj " + java.text.DateFormat.getDateInstance(java.text.DateFormat.LONG, new Locale("hi", "IN")).format(new java.util.Date()) + " hai."));
        reply = new TextView(this); reply.setText("Namaste! Main basic commands mein madad kar sakta hoon."); reply.setTextColor(0xFFFFFFFF); reply.setTextSize(17); reply.setPadding(0, 24, 0, 12); root.addView(reply);
        setContentView(root);
    }
    private void addButton(LinearLayout root, String label, android.view.View.OnClickListener listener) { Button b = new Button(this); b.setText(label); root.addView(b, new LinearLayout.LayoutParams(-1, -2)); b.setOnClickListener(listener); }
    private void say(String text) { reply.setText(text); if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dear_reply"); }
    private void startVoice() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { say("Is phone par speech recognition available nahi hai."); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO); return; }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN"); i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Boliye");
        try { startActivityForResult(i, REQ_SPEECH); } catch (Exception e) { say("Voice input shuru nahi ho paya."); }
    }
    @Override protected void onActivityResult(int request, int result, Intent data) { super.onActivityResult(request, result, data); if (request == REQ_SPEECH && result == RESULT_OK && data != null) { ArrayList<String> a = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS); if (a != null && !a.isEmpty()) { command.setText(a.get(0)); runCommand(a.get(0)); } } }
    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) { super.onRequestPermissionsResult(r,p,g); if (r == REQ_AUDIO && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) startVoice(); else say("Microphone permission ke bina voice input nahi chalega."); }
    private void runCommand(String s) {
        String q = s == null ? "" : s.trim(); String l = q.toLowerCase(Locale.ROOT);
        if (l.isEmpty()) { say("Pehle command likhein ya boliye."); return; }
        if (l.contains("time") || l.contains("समय") || l.contains("kitne baje")) { say("Abhi " + java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT, new Locale("en", "IN")).format(new java.util.Date()) + " baj rahe hain."); }
        else if (l.contains("date") || l.contains("तारीख")) { say("Aaj " + java.text.DateFormat.getDateInstance(java.text.DateFormat.LONG, new Locale("hi", "IN")).format(new java.util.Date()) + " hai."); }
        else if (l.startsWith("call ") || l.startsWith("कॉल ")) { String n = q.replaceAll("[^0-9+]", ""); if (n.length() >= 5) { startActivity(new Intent(Intent.ACTION_DIAL, android.net.Uri.parse("tel:" + n))); say("Dialer khol raha hoon. Call karne se pehle number check kar lein."); } else say("Number ke saath command dein."); }
        else if (l.contains("search ") || l.startsWith("खोजो ")) { String term = q.substring(q.indexOf(' ') + 1); startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com/search?q=" + android.net.Uri.encode(term)))); say("Web search khol raha hoon."); }
        else if (l.contains("booking") || l.contains("बुकिंग") || l.contains("ticket") || l.contains("टिकट")) { startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com/search?q=" + android.net.Uri.encode(q + " booking")))); say("Booking search khol raha hoon."); }
        else if (l.contains("message") || l.contains("sms") || l.contains("मैसेज")) { Intent i = new Intent(Intent.ACTION_SENDTO, android.net.Uri.parse("smsto:")); i.putExtra("sms_body", q); startActivity(i); say("SMS draft khol raha hoon. Bhejne se pehle review karein."); }
        else say("Abhi main time, date, voice input, phone dialer, SMS draft aur web search jaise basic commands support karta hoon. Full AI chat aur always-on Dear wake word is build mein nahi hai.");
    }
    @Override protected void onDestroy() { if (tts != null) { tts.stop(); tts.shutdown(); } super.onDestroy(); }
}
