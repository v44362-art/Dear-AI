# DEAR AI — Android starter project

This is a basic Android voice-command prototype. It supports Hindi speech input (through the phone's speech-recognition service), spoken replies, time/date, opening the phone dialer, opening an SMS draft, web search, and booking search.

## Build APK using GitHub Actions
1. Upload **all files and folders in this project** to the root of a GitHub repository. Include the hidden `.github` folder and its `workflows/android-apk.yml` file.
2. Open the repository's **Actions** tab.
3. Select **Build DEAR AI APK** and tap **Run workflow**.
4. When the run succeeds, open it and download the `DEAR-AI-debug-APK` artifact.
5. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.

This is a debug APK for testing, not a Play Store release. It is not an unrestricted AI assistant and does not provide an always-on wake word or full offline general-purpose AI. Calls and messages require user confirmation in the phone's native apps.
